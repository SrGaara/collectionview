//
//  LostCollectionViewCell.swift
//  Actividad11_ReviewsCollection
//
//  Created by Alumno IDS on 19/04/18.
//  Copyright © 2018 Alumno IDS. All rights reserved.
//

import UIKit

    // Contenido de todas las cell
class PlacesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemLabel: UILabel!
    

}
